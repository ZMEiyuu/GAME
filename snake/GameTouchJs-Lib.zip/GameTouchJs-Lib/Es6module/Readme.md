### How to use it ?
```javascript
import * as gametouch from "./gametouch-es6module.js"
let controller = new gametouch.crossButton()
let attackB = new gametouch.freeButton()


```

Attach gametouch. to everything and you are done the doc stay the same
