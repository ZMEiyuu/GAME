#### GameTouchJs
is a lightweight library designed to create
a  button controller for mobile device ( Smartphones and Tablets ) games with fewer lines of codes.


<pre><code>
&lt;script src="https://cdn.jsdelivr.net/gh/JcerelusDev/GameTouchJs/gametouch.min.js"&gt;&lt;/script&gt;
</code></pre>
The documentation link :

<a href="https://github.com/JcerelusDev/GameTouchJs/wiki">Docs</a>



Jcerelus Dev All Rights Reserved 

Developer : Jean .F CÉRÉLUS
